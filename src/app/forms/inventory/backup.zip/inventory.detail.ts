import { Component, EventEmitter, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { GenericDetail } from "app/forms/generic/generic.detail";
import { Inventory } from "app/model/api/inventory/inventory";

@Component({
    selector: 'inventory-detail',
    templateUrl: 'inventory.detail.html'
})
export class InventoryDetail extends GenericDetail<Inventory, number> {

    @ViewChild('detailForm') detailForm: FormGroup;

    private get inventoryActiveState(): string { return this.item.active ? 'Da' : 'Nu'; }

    setItemDefaultValues() {
        this.item = new Inventory();
        this.item.start = new Date();
        this.item.end = new Date();
    }

    protected resetForm() {
        this.detailForm.reset();
    }

    private updateActive(active: boolean) {
        this.item.active = active;
    }

    private parseDate(dateString: string): Date {
        if (dateString) {
            return new Date(dateString);
        } else {
            return null;
        }
    }
}