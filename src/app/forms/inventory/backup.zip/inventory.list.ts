import { Component } from '@angular/core';

import { TranslateService } from '@ngx-translate/core';
import { Inventory } from "app/model/api/inventory/inventory";
import { GenericTableList } from "app/forms/generic/generic.table.list";

@Component({
    selector: 'inventory-list',
    templateUrl: 'inventory.list.html'
})
export class InventoryList extends GenericTableList<Inventory, number> {
    receiveData: string;
    selectLang = this.receiveData;

    constructor(private translate: TranslateService) {
        super('id', 'desc');

        translate.use(this.receiveData);
    }

}