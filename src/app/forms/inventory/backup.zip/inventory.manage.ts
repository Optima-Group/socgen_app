import { AppConfig } from 'app/config';
import { TranslateService } from '@ngx-translate/core';
import { Component, EventEmitter, ViewChild } from '@angular/core';
import { ModalDirective } from 'ng2-bootstrap';

import { Inventory } from 'app/model/api/inventory/inventory';
import { InventoryHttpService } from 'app/services/http/inventory/inventory.http.service';
import { GenericManage } from 'app/forms/generic/generic.manage';
import { LocationHttpService } from 'app/services/http/administration/location.http.service';
@Component({
    selector: 'inventory-manage',
    templateUrl: 'inventory.manage.html',
    providers: [ InventoryHttpService, LocationHttpService ]
})
export class InventoryManage extends GenericManage<Inventory, number> {

    @ViewChild('itemDetailModal') modal: ModalDirective;

    private filter: string = '';

    constructor(private inventoryHttpService: InventoryHttpService, private translate: TranslateService) {
        super();
        translate.use(AppConfig.TRANSLATE_DEFAULT_LANGUAGE);
    }

    protected detailInitialize() {
        this.modal.show();
    }

    protected detailTerminate() {
        this.modal.hide();
    }
}
